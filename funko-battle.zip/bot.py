import os
from telegram import Update, WebAppInfo, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, ContextTypes
from dotenv import load_dotenv

# Cargar variables de entorno
load_dotenv()

# Obtener el token del bot
TOKEN = os.getenv('TELEGRAM_BOT_TOKEN')

# URL de la webapp en PythonAnywhere (reemplaza TU_USUARIO con tu nombre de usuario de PythonAnywhere)
WEBAPP_URL = 'https://TU_USUARIO.pythonanywhere.com'

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando /start - Muestra el botón para abrir la mini app"""
    keyboard = [
        [InlineKeyboardButton(
            " Jugar Funko Battle", 
            web_app=WebAppInfo(url=WEBAPP_URL)
        )]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        "¡Bienvenido a Funko Battle! \n\n"
        "Colecciona, mejora y batalla con tus Funkos favoritos.\n"
        "Haz clic en el botón de abajo para comenzar:",
        reply_markup=reply_markup
    )

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando /help - Muestra información de ayuda"""
    help_text = (
        " *Funko Battle - Comandos*\n\n"
        "/start - Iniciar el juego\n"
        "/help - Mostrar este mensaje de ayuda\n"
        "/profile - Ver tu perfil\n"
        "/daily - Reclamar recompensa diaria\n\n"
        " *Tips*:\n"
        "- Colecciona Funkos de diferentes rarezas\n"
        "- Mejora tus Funkos para aumentar su poder\n"
        "- Participa en batallas para ganar monedas\n"
        "- Compra cajas misteriosas en la tienda"
    )
    await update.message.reply_text(help_text, parse_mode='Markdown')

async def profile(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando /profile - Muestra el perfil del usuario"""
    # Aquí deberías obtener los datos del usuario de la base de datos
    await update.message.reply_text(
        " *Tu Perfil*\n\n"
        "Nivel: 1\n"
        "FunkoCoins: 0\n"
        "Funkos Coleccionados: 0\n"
        "Batallas Ganadas: 0",
        parse_mode='Markdown'
    )

async def daily(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comando /daily - Recompensa diaria"""
    # Aquí deberías implementar la lógica de recompensa diaria
    await update.message.reply_text(
        " *¡Recompensa Diaria!*\n\n"
        "Has recibido:\n"
        "+ 100 FunkoCoins\n"
        "+ 1 Caja Común",
        parse_mode='Markdown'
    )

def main():
    """Función principal para iniciar el bot"""
    # Crear la aplicación
    application = Application.builder().token(TOKEN).build()

    # Agregar manejadores de comandos
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("profile", profile))
    application.add_handler(CommandHandler("daily", daily))

    # Iniciar el bot
    print("Bot iniciado...")
    application.run_polling()

if __name__ == '__main__':
    main()
