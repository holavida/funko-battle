# Funko Battle - Mini App de Telegram

Una aplicación de Telegram para coleccionar, mejorar y batallar con Funkos.

## Configuración en PythonAnywhere

1. **Crear una cuenta en PythonAnywhere**
   - Ve a [PythonAnywhere](https://www.pythonanywhere.com) y crea una cuenta gratuita

2. **Subir el código**
   ```bash
   # En la consola de PythonAnywhere:
   git clone https://github.com/TU_USUARIO/funko-battle.git
   ```

3. **Configurar el entorno virtual**
   ```bash
   mkvirtualenv --python=/usr/bin/python3.9 funko-battle-env
   pip install -r requirements.txt
   ```

4. **Configurar la aplicación web**
   - Ve a la pestaña "Web"
   - Haz clic en "Add a new web app"
   - Selecciona "Manual configuration"
   - Selecciona Python 3.9
   - En "Code" configura:
     - Source code: `/home/TU_USUARIO/funko-battle`
     - Working directory: `/home/TU_USUARIO/funko-battle`
     - WSGI configuration file: `/home/TU_USUARIO/funko-battle/funko_battle_app.wsgi`

5. **Configurar variables de entorno**
   - En la pestaña "Files", edita `/home/TU_USUARIO/.env`:
   ```
   TELEGRAM_BOT_TOKEN=tu_token_del_bot
   FLASK_SECRET_KEY=una_clave_secreta_aleatoria
   DATABASE_URL=sqlite:////home/TU_USUARIO/funko-battle/funko_battle.db
   ```

6. **Actualizar archivos de configuración**
   - En `app.py`: Reemplaza `TU_USUARIO` con tu nombre de usuario de PythonAnywhere
   - En `bot.py`: Reemplaza `TU_USUARIO` con tu nombre de usuario de PythonAnywhere
   - En `funko_battle_app.wsgi`: Reemplaza `TU_USUARIO` con tu nombre de usuario de PythonAnywhere

7. **Iniciar el bot**
   ```bash
   # En una nueva consola de PythonAnywhere:
   cd funko-battle
   python bot.py
   ```

8. **Reiniciar la aplicación web**
   - Ve a la pestaña "Web"
   - Haz clic en "Reload TU_USUARIO.pythonanywhere.com"

## Estructura del Proyecto

```
funko-battle/
├── app.py              # Servidor Flask
├── bot.py             # Bot de Telegram
├── requirements.txt   # Dependencias
├── funko_battle.db   # Base de datos SQLite
└── static/           # Archivos estáticos
    ├── css/
    ├── js/
    └── images/
```

## Características

- Colección de Funkos
- Sistema de batallas
- Tienda con cajas misteriosas
- Sistema de mejora de Funkos
- Moneda virtual (FunkoCoins)
- Recompensas diarias

## Tecnologías Utilizadas

- Python 3.9
- Flask
- SQLAlchemy
- python-telegram-bot
- Web3.py
